// =================================================================
// 1. COUNTDOWN TIMER LOGIC
// =================================================================

// 💖 CUSTOMIZATION: Set your anniversary or next date here.
// Format: "Month Day, Year Hour:Minute:Second"
// Example: "Dec 31, 2026 18:30:00"
const targetDate = new Date("October 22, 2025 00:00:00").getTime();

const countdown = document.getElementById('timer');
const daysSpan = document.getElementById('days');
const hoursSpan = document.getElementById('hours');
const minutesSpan = document.getElementById('minutes');
const secondsSpan = document.getElementById('seconds');

function updateCountdown() {
    const now = new Date().getTime();
    const distance = targetDate - now;

    // Time calculations for days, hours, minutes and seconds
    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    if (distance < 0) {
        // If the countdown is over, display a special message
        clearInterval(timerInterval);
        countdown.innerHTML = '<span class="dancing-font" style="font-size: 2em; color: var(--color-accent);">Happy Day! You are my greatest gift!</span>';
    } else {
        // Display the results with leading zeros
        daysSpan.textContent = String(days).padStart(2, '0');
        hoursSpan.textContent = String(hours).padStart(2, '0');
        minutesSpan.textContent = String(minutes).padStart(2, '0');
        secondsSpan.textContent = String(seconds).padStart(2, '0');
    }
}

// Update the countdown every 1 second
const timerInterval = setInterval(updateCountdown, 1000);

// Run immediately to avoid a 1-second delay
updateCountdown();


// =================================================================
// 2. LOVE NOTES GENERATOR LOGIC
// =================================================================

// 💖 CUSTOMIZATION: Add, remove, or change these sweet messages!
const loveNotes = [
    "On your birthday I wish I could teleport to you. Until then Ill send all my kisses through the night sky — look up and know I’m thinking of you. ✨",
    "This distance cant measure how much I loveeeeeee uhhhhhhh.",
    "You are my favorite notification. 🔔",
    "I wish I could hold you close and whisper happy birthday in your ear — but until then, Im sending a thousand hugs through the stars.🌙💋",
    "I wish I could teleport to you. Until then Ill send all my kisses through the night sky — look up and know Im thinking of you.",
    "Being with you is the only place I ever want to be. U're MY HOME🏡"
];

const loveQuoteElement = document.getElementById('love-quote');
const generateNoteButton = document.getElementById('generate-note');

generateNoteButton.addEventListener('click', () => {
    // Get a random index
    const randomIndex = Math.floor(Math.random() * loveNotes.length);
    // Display the random quote with a little animation effect
    loveQuoteElement.style.opacity = 0;
    setTimeout(() => {
        loveQuoteElement.textContent = loveNotes[randomIndex];
        loveQuoteElement.style.opacity = 1;
    }, 300); // 300ms delay for fade in
});


// =================================================================
// 3. FLOATING HEARTS ANIMATION
// =================================================================

const heartContainer = document.querySelector('.heart-container');
const heartsToGenerate = 25; // Number of hearts on screen

function createHeart() {
    const heart = document.createElement('div');
    heart.classList.add('heart');
    // Using a Font Awesome heart icon
    heart.innerHTML = '<i class="fas fa-heart"></i>';

    // Random starting position (x-axis)
    heart.style.left = `${Math.random() * 100}vw`;
    // Random animation duration for variety
    heart.style.animationDuration = `${(Math.random() * 8) + 7}s`; // 7s to 15s

    heartContainer.appendChild(heart);

    // Remove the heart after it floats up to save memory
    setTimeout(() => {
        heart.remove();
    }, 15000); // Remove after 15 seconds (max duration)
}

// Create a new heart at a random interval
setInterval(createHeart, 500);


// =================================================================
// 4. SURPRISE PAGE TOGGLE
// =================================================================

const surpriseLink = document.querySelector('.secret-link');
const surprisePage = document.getElementById('surprise');

surpriseLink.addEventListener('click', (e) => {
    e.preventDefault(); // Prevent default anchor jump behavior
    // Toggle the display property (which is set to 'none' in CSS)
    if (surprisePage.style.display === 'flex') {
        surprisePage.style.display = 'none';
        // Change body overflow back if it was set
        document.body.style.overflow = 'auto';
    } else {
        surprisePage.style.display = 'flex';
        // Hide scrollbar when the surprise is full screen
        document.body.style.overflow = 'hidden';
    }
});

// Allow the user to close the surprise page by clicking anywhere on it
surprisePage.addEventListener('click', () => {
    surprisePage.style.display = 'none';
    document.body.style.overflow = 'auto';
});